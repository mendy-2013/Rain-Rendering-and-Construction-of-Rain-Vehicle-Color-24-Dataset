All the results in the paper are available at https://pan.baidu.com/s/1Oym9G-8Bq-0FU2BfbARf8g .

Please place the downloaded results into `./results/`, and then you can directly compute all the evaluation metrics using Matlab scripts in `./statistic/`