#! bash

# Rain100H
python train_PRN_r.py --save_path logs/Rain100H/PRN_r --data_path datasets/train/RainTrainH

# Rain100L
python train_PRN_r.py --save_path logs/Rain100L/PRN_r --data_path datasets/train/RainTrainL

# Rain12600
python train_PRN_r.py --save_path logs/Rain1400/PRN_r --data_path datasets/train/Rain12600
